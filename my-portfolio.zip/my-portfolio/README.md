# My Portfolio

A plain HTML/CSS/JS portfolio site. No frameworks, no build step.

## Run it on your computer
Just double-click `index.html`.
For auto-refresh while editing, use VS Code with the "Live Server" extension:
right-click `index.html` -> "Open with Live Server".

## What to edit (search for "EDIT" in index.html)
1. Page title + description (top of index.html)
2. Your initials in the nav logo
3. Hero: name, one-line story, bio, badges
4. Photo: replace `images/profile.svg` (or point the <img> at your own file)
5. Stats, Work cards, Social links, Timeline, Email
6. Colors: the `:root` block at the top of style.css (change `--accent`)

## Put it online free with GitHub Pages
1. Create a GitHub repo named exactly `YOURUSERNAME.github.io`
2. In this folder, run:

   git init
   git add .
   git commit -m "first version"
   git branch -M main
   git remote add origin https://github.com/YOURUSERNAME/YOURUSERNAME.github.io.git
   git push -u origin main

3. Visit https://YOURUSERNAME.github.io after a minute or two.

## Files
- index.html  page content
- style.css   design (colors, layout, cursor, nav)

- images/     photo + favicon
